class MetricComputationError(Exception):
    """Exception raised when a metric cannot be computed."""

    pass
