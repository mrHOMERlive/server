# coding: utf-8

# Pandoc
import pandoc

pandoc.main()
