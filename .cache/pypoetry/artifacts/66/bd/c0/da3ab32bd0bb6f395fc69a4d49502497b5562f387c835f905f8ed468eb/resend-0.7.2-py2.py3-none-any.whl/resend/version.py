__version__ = "0.7.2"


def get_version():
    """Returns the current version of this lib

    Returns:
        str: version number
    """
    return __version__
