from ._block import compress, decompress, LZ4BlockError  # noqa: F401
