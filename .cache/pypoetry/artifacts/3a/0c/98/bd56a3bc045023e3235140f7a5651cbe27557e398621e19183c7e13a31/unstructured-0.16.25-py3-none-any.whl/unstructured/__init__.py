from .partition.utils.config import env_config

# init env_config
env_config
