from unstructured.partition.html.partition import partition_html

__all__ = ["partition_html"]
