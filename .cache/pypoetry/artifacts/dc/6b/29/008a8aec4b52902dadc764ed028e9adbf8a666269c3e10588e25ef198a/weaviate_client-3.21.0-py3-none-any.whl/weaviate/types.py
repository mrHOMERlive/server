import uuid
from typing import Union

UUID = Union[str, uuid.UUID]
NUMBERS = Union[int, float]
