"""
Contextionary module used to interact with Weaviate's contextionary module.
"""

__all__ = ["Contextionary"]

from .crud_contextionary import Contextionary
