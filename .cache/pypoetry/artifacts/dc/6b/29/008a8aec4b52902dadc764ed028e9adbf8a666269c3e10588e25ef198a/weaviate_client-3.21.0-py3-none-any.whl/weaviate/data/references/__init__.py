"""
Module for adding, deleting and updating references in-between objects.
"""

__all__ = ["Reference"]

from .crud_references import Reference
