# TiDB Vector has a limitation on the dimension length
MAX_DIMENSION_LENGTH = 16000
MIN_DIMENSION_LENGTH = 1
