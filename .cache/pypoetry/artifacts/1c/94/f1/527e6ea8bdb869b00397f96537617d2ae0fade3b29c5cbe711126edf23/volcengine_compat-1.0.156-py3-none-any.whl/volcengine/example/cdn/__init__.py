ak = ''
sk = ''
